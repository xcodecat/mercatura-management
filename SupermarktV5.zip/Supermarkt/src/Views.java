public abstract class Views {
	
	protected Datenbank datenbank;
	
	public Views() {
		
	}

}