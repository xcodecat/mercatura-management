public class SupermarktStarter {

	public static void main(String[] args) {
			
		Datenbank datenbank = new Datenbank();
	    /*Kassierer kassierer = */new Kassierer(datenbank);
	    /*Lagermitarbeiter lagermitarbeiter = */new LagermitarbeiterView(datenbank);
	    /*Kunde kunde = */new Kunde(datenbank);
	    ///*GeschaeftsfuehrerView gView = */new GeschaeftsfuehrerView(datenbank);
	        
	}

}